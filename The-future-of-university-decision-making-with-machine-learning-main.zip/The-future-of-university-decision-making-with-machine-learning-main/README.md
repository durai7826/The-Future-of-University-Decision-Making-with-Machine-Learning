# The-future-of-university-decision-making-with-mechine-learning
# Video Demostration - https://youtu.be/o3aktpphaSw



# PERIYAR ARTS COLLEGE,CUDDALORE


# NM Id : 2EBF4EB0674B2609FA4467DBE9256EBE
# Email : selvaraj1662003@gmail.com

# TEAM MEMBERS :
     * SELVARAJ I
     * VIJAYAKUMAR M
     * SIVABALAN P
     * SANMUGAM M



     
     

